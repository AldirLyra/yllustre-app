import path from 'node:path';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import ffmpeg from '@ffmpeg-installer/ffmpeg';
const root=process.cwd();
const native=path.join(root,'node_modules/@remotion/compositor-win32-x64-msvc');
const fullff=path.dirname(ffmpeg.path);
const env={...process.env,Path:fullff+path.delimiter+native+path.delimiter+process.env.Path,PATH:fullff+path.delimiter+native+path.delimiter+(process.env.PATH??process.env.Path)};
const file=path.resolve(root,'../entregas/yllustre-eventos-v1-final.mp4');
const ff=ffmpeg.path;
const script=path.join(root,'skill/criador-de-videos/scripts/verificar-video.mjs');
const result=execFileSync(process.execPath,[script,file,'--duration','45','--width','1080','--height','1920','--fps','30','--frames','1350','--audio','required'],{env,encoding:'utf8',timeout:300000});
fs.writeFileSync(path.join(root,'review/technical-report.json'),result);
console.log(result);
const frames=[100,225,380,540,730,900,1110,1300];
execFileSync(ff,['-v','error','-y','-i',file,'-vf',`select='${frames.map(n=>`eq(n,${n})`).join('+')}',scale=270:480,tile=4x2:padding=8:margin=8`,'-frames:v','1',path.join(root,'review/mp4-storyboard.jpg')],{timeout:120000});
for(const cut of [150,300,450,630,810,990,1170]){
 const at=[cut-12,cut-8,cut-4,cut,cut+4,cut+8];
 execFileSync(ff,['-v','error','-y','-i',file,'-vf',`select='${at.map(n=>`eq(n,${n})`).join('+')}',scale=180:320,tile=6x1:padding=5:margin=5`,'-frames:v','1',path.join(root,`review/transition-${cut}.jpg`)],{timeout:120000});
}
execFileSync(ff,['-v','error','-y','-i',file,'-vf',"select='eq(n,100)'",'-frames:v','1',path.resolve(root,'../entregas/yllustre-eventos-capa.jpg')],{timeout:120000});
console.log('Extracted all scenes and 7 transition contact sheets from the exported MP4.');
