import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, selectComposition, renderStill, renderMedia} from '@remotion/renderer';

const root=process.cwd();
const mode=process.argv[2]??'stills';
const executable='C:/Program Files/Google/Chrome/Application/chrome.exe';
console.log('Bundling',mode);
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),outDir:path.join(root,'build'),publicDir:path.join(root,'public'),onProgress:p=>{if(p%20===0)console.log('Bundle',p);}});
console.log('Opening render browser');
const browser=await openBrowser('chrome',{browserExecutable:executable});
console.log('Selecting composition');
try {
 const composition=await selectComposition({serveUrl,id:'YllustreEventos',puppeteerInstance:browser});
 if(mode==='stills'){
   for(const frame of [0,100,225,380,540,730,900,1110,1300]){
     await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,output:path.join(root,`review/frame-${frame}.png`),scale:.5});
     console.log('Still',frame);
   }
 } else {
   let last=0;
   await renderMedia({serveUrl,composition,puppeteerInstance:browser,outputLocation:path.join(root,'../entregas/yllustre-eventos-v1-final.mp4'),codec:'h264',crf:18,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'256k',concurrency:2,onProgress:({progress})=>{const p=Math.floor(progress*100);if(p>=last+10){last=p;console.log('Render',p+'%');}}});
 }
} finally {await browser.close({silent:true});}
